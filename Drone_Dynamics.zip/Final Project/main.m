clear all;clc
%% Step1: initialization
Enviroment.g=9.81;
Chassis.dim=[24 12 4]*1e-2;
Chassis.m=[1];
Chassis.CG=[0  0  0];
Chassis.J=[1 1 1]*1e-2;
Arm.dim=[2*25 2 1]*1e-2;
Arm.m=0.05*2;
Arm.rho=Arm.m/prod(Arm.dim);

Motor.r=28e-3;
Motor.h=13e-3;
Motor.J = diag([1237.11, 0.01, -0.03; 0.01, 1237.18, 0.03; 0.03, 0.03, 1909.49]*1e-3*1e-6);
Motor.m=38e-3;
Motor.CG = [0 0 Motor.h]*1e-3;

Propeller.m=10.11e-3;
Propeller.rho=940;

%% drone mass and inertial
Drone.m=Chassis.m+(Motor.m+Propeller.m)*4+Arm.m*2;
Drone.I=4*Motor.J+(Motor.m+Propeller.m)*2*(Arm.dim(1)/2)^2;

%% Initial Conditions
Simulation.x0=[10;1;-2];
Simulation.v0=[1;2;0];
Simulation.zyx0=1*deg2rad([-10;20;30]);
Simulation.wb0=1*deg2rad([1;2;3])
%% IMU Noise Covariances
noise.acc=0.001;
noise.omega=0.001;


tmp=(Chassis.dim).^2;
Chassis.I=1/12*Chassis.m*diag([tmp(2)+tmp(3);tmp(1)+tmp(3);tmp(2)+tmp(1)]);

tmp=(Arm.dim).^2;
Arm.I=1/12*Arm.m*diag([tmp(2)+tmp(3);tmp(1)+tmp(3);tmp(2)+tmp(1)]);

Total.m=Chassis.m+4*(Motor.m+Propeller.m)+2*Arm.m;
Total.J=Chassis.I+diag([Motor.m*(Arm.dim(1)/2)^2*[2 2 4]])+Arm.I;

Ix=Total.J(1);
Iy=Total.J(2,2);
Iz=Total.J(3,3);

m=Total.m;

%% Step2: Full Nonlinear Model


syms x y z vx vy vz phi theta psi p q r dpsi dtheta  dphi real 

ksi=[x,y,z].'; 
dksi=[vx,vy,vz].'; 
etha=[psi theta phi ].';
detha=[dpsi dtheta dphi].';

qq=[ksi;etha];
Omega_B=[p q r].';

R=Rotation(etha,'xyz');

dRdt=reshape(simplify(jacobian(R(:),etha)*detha),3,[]); 
Omega_dual=R.'*dRdt;
Omega_B=simplify(dual2vec(Omega_dual))
PI=simplify(jacobian(Omega_B,detha))

syms T m g
NONLINEAR_EOM_RHS_trans=simplify(-g*[0;0;1]+R*[0;0;1]*T/m);
% Rotation EOM

syms Ix Iy Iz
I=diag([Ix,Iy,Iz]);

syms tau_x tau_y tau_z
I=diag([Ix,Iy,Iz]);
Omega_B=[p q r].';
tau_B=[tau_x tau_y tau_z].';

NONLINEAR_EOM_RHS_rot=simplify(I^-1*(-cross(Omega_B,I*Omega_B)+tau_B));


F_translation=simplify([dksi;NONLINEAR_EOM_RHS_trans])
F_rotation=simplify([NONLINEAR_EOM_RHS_rot;PI^-1*Omega_B])

F=[F_translation;F_rotation]

%% Step4(Reduced Continuous LinearizedModel)

X=[ksi;dksi;Omega_B;etha]; 
U=[tau_x tau_y tau_z T].';


r_m_S=[1:2,4:5];
redState=setdiff(1:12,r_m_S);

reduce_X=X(redState);
F_r=F(redState);

Bs=jacobian(F_r,U);
As=jacobian(F_r-Bs*U,reduce_X);

syms x0 y0 z0
X_e=[z0 0 0 0 0 0 0 0].';

A=(subs(As,reduce_X,X_e));
B=(subs(Bs,reduce_X,X_e));
linearize_model=simplify(A*reduce_X+B*U);

%% Step5(Reduced Continuous LinearizedModel LQR)
Ix=Total.J(1);
Iy=Total.J(2,2);
Iz=Total.J(3,3);
m=Total.m;
A=eval(subs(A));
B=eval(subs(B));
Q=diag([10*ones(1,2) 100*ones(1,6)]);
R=eye(4,4);
K=lqr(A,B,Q,R)

%
Control.States=[3 6 7 8 9 10 11 12]
%% Step5:Simulation Reduced Continuous Linearized Model LQR

sim('quadcopter_reduced.slx')

%% Step6:Simulation Reduced Continuous Linearized Model_zoh LQR

sim('quadcopter_reduced_zoh.slx')
%% Step7: Simulation ReducedDiscrete Linearized  Model LQR,
Ts=0.2
K_d= lqrd (A,B,Q,R,Ts)

%% Step8:Full Discrete Linearized
g=Enviroment.g
A2=[
0 0 0 1 0 0 0 0 0 0 0 0
0 0 0 0 1 0 0 0 0 0 0 0
0 0 0 0 0 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 g 0
0 0 0 0 0 0 0 0 0 0 0 -g
0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 1 0 0 0
0 0 0 0 0 0 0 1 0 0 0 0
0 0 0 0 0 0 1 0 0 0 0 0];

B2=[0 0 0 0
    0 0 0 0
    0 0 0 0
    0 0 0 0
    0 0 0 0
 1/m 0 0 0 
0 1/Ix 0 0
0 0 1/Iy 0 
0 0 0 1/Iz 
0 0 0 0
0 0 0 0
0 0 0 0];


X=[ksi;dksi;Omega_B;etha]; 
U=[tau_x tau_y tau_z T].';

%L=simplify(A*X+B*U)
rank(ctrb(A2,B2))%fully ranked
ts=0.2;
Q2=eye(12);
R2=eye(4);
K_12=lqrd(A2,B2,Q2,R2,ts)

%% Step9:Simulation Full DiscreteLinearized Model LQRD:
sim('quadcopter_fully_zoh.slx')
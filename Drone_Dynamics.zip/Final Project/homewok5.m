Body.dim=[24 12 4]*1e-2;
Body.m = [1];
Body.CG =[0 0 0];
Body.J = [1e-2 1e-2 1e-2];

%arms details
Arm.dim=[2*25 2 1]*1e-2;
Arm.m = 0.05*2;
Arm.rho=Arm.m/prod(Arm.dim);
%motors details
Motor.r = 28e-3;
Motor.h = 13e-3;
Motor.Jr = diag([1237.11, 0.01, -0.03 ,0.01 , 1237.18, 0.03, 0.03, 0.03, 1909.49]*1e-3*1e-6);
Motor.m=38e-3;
Motor.CG = [0 0 Motor.h]*1e-3;

%propellers

Propellers.m = 10.11e-3;
Propellers.v = 9913;
Propeller.rho=940;

%% drone mass and inertial
Drone.m=Chassis.m+(Motor.m+Propeller.m)*4+Arm.m*2;
Drone.I=4*Motor.J+(Motor.m+Propeller.m)*2*(Arm.dim(1)/2)^2;

%% Initial Conditions
Simulation.x0=[10;1;-2];
Simulation.v0=[1;2;0];
Simulation.zyx0=1*deg2rad([-10;20;30]);
Simulation.wb0=1*deg2rad([1;2;3])
%% IMU Noise Covariances
noise.acc=0.001;
noise.omega=0.001;